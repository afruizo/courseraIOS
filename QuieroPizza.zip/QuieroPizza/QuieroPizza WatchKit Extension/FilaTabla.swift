//
//  FilaTabla.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 26/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit

class FilaTabla: NSObject {

    @IBOutlet var switchItem: WKInterfaceSwitch!
    var resultado:Bool = false
    
    
    @IBAction func obtenerResultado(_ value: Bool) {
        self.resultado = value
    }
    
    func getResultado() -> Int{
        
        if self.resultado == true{
            return 0
        }else{
            return 1
        }
    }

}
