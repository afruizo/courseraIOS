//
//  IC_TipoMasa.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 25/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class IC_TipoMasa: WKInterfaceController {

    @IBOutlet var pickerMasa: WKInterfacePicker!
    
    var valorTipoMasa: Int = 0
    
    let tipoMasa : [(String, String)] = [
        ("Delgada", "Delgada"),
        ("Crujiente", "Crujiente"),
        ("Gruesa", "Gruesa")
    ]
    
    var contexto:ValoresPizza = ValoresPizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        contexto = context as! ValoresPizza
        
        // Configure interface objects here.
        let tipoMasaItems: [WKPickerItem] = tipoMasa.map{
            let tipoMasaItem = WKPickerItem()
            tipoMasaItem.title = $0.0
            tipoMasaItem.caption = $0.1
            
            return tipoMasaItem
        }
        
        pickerMasa.setItems(tipoMasaItems)
        pickerMasa.setSelectedItemIndex(1)
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func obtenerSeleccion(_ value: Int) {
        valorTipoMasa = value
    }
    
    
    @IBAction func continuarFlujo() {
        contexto.setTipoMasa(tm: valorTipoMasa)
        pushController(withName: "VistaTipoQueso", context: contexto)
    }
}
