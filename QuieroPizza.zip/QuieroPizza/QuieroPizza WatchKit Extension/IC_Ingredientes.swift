//
//  IC_Ingredientes.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 26/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class IC_Ingredientes: WKInterfaceController {

    
    
    var swJamon: Int = 0
    var swPeperoni: Int = 0
    var swPavo: Int = 0
    var swSalchicha: Int = 0
    var swAceituna: Int = 0
    var swCebolla: Int = 0
    var swPimiento: Int = 0
    var swPiña: Int = 0
    var swAnchoa: Int = 0
    
    var ingredientes:[Bool] = [false,false,false,false,false,false,false,false,false]
    
    /*
      0 = false
      1 = true
     */
    
    var contexto: ValoresPizza = ValoresPizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        contexto = context as! ValoresPizza
        // Configure interface objects here.
        
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    @IBAction func selectorJamon(_ value: Bool) {
        ingredientes[0] = value
    }
    
    @IBAction func selectorPeperoni(_ value: Bool) {
        ingredientes[1] = value
    }
    
    @IBAction func selectorPavo(_ value: Bool) {
        ingredientes[2] = value
    }
    
    @IBAction func selectorSalchicha(_ value: Bool) {
        ingredientes[3] = value
    }
    
    @IBAction func selectorAceituna(_ value: Bool) {
        ingredientes[4] = value
    }
    
    @IBAction func selectorCebolla(_ value: Bool) {
        ingredientes[5] = value
    }
    
    @IBAction func selectorPimiento(_ value: Bool) {
        ingredientes[6] = value
    }
    
    @IBAction func selectorPina(_ value: Bool) {
        ingredientes[7] = value
    }
    
    @IBAction func selectorAnchoa(_ value: Bool) {
        ingredientes[8] = value
    }


    @IBAction func continuarFlujo() {
        contexto.setIngredientes(ing: ingredientes)
        pushController(withName: "Confirmacion", context: contexto)
    }
}
