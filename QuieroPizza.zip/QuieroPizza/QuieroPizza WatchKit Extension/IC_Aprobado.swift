//
//  IC_Aprobado.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 26/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class IC_Aprobado: WKInterfaceController {
    
    
    @IBOutlet var lblMensajeSatisfactorio: WKInterfaceLabel!

    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
    
        let cadena: String = "👍\n Hemos procesado tu pedido. Muchas gracias\n😃"
        
        self.lblMensajeSatisfactorio.setText(cadena)
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
