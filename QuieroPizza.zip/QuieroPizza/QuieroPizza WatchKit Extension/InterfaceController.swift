//
//  InterfaceController.swift
//  QuieroPizza WatchKit Extension
//
//  Created by Andres Fernando Ruiz Ojeda on 25/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {

    @IBOutlet var pickerTamano: WKInterfacePicker!
    
    var valorSeleccionado : Int = 0
    
    let tamanoPizza : [(String, String)] = [
        ("Chica", "4 slides"),
        ("Mediana", "6 slides"),
        ("Grande", "8 slides")
    ]
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
        let tamanoPizzaItems: [WKPickerItem] = tamanoPizza.map{
            let tamanoPizzaItem = WKPickerItem()
            tamanoPizzaItem.title = $0.0
            tamanoPizzaItem.caption = $0.1
            
            return tamanoPizzaItem
        }
        
        pickerTamano.setItems(tamanoPizzaItems)
        pickerTamano.setSelectedItemIndex(1)
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func obtenerSeleccion(_ value: Int) {
        valorSeleccionado = value
    }
    
    
    @IBAction func continuarFlujo() {
        let contexto = ValoresPizza()
        contexto.setTamanoPizza(tp: valorSeleccionado)
        pushController(withName: "VistaTipoMasa", context: contexto)
    }
}
