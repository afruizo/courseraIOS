//
//  IC_Confirmacion.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 26/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class IC_Confirmacion: WKInterfaceController {

    @IBOutlet var mensajePedido: WKInterfaceLabel!
    
    var contexto: ValoresPizza = ValoresPizza()
    var cadena:String = ""
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        contexto = context as! ValoresPizza
        // Configure interface objects here.
        
        cadena = contexto.procesaTamanoPizza(tp: contexto.getTamanoPizza())
        cadena = cadena + contexto.procesaTipoMasa(tm: contexto.getTipoMasa())
        cadena = cadena + contexto.procesaTipoQueso(tq: contexto.getTipoQueso())
        cadena = cadena + contexto.procesaIngredientes(ing: contexto.getIngredientes())
        
        self.mensajePedido.setText(cadena)
        
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func aprobarPedido() {
        pushController(withName: "Procesado", context: contexto)
    }
}
