//
//  ValoresPizza.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 25/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit

class ValoresPizza: NSObject {
    var tamanoPizza: Int = 0
    var tipoMasa: Int = 0
    var tipoQueso: Int = 0
    var ingredientes: [Bool] = []

    
    //init(tp: Int, tm: Int, tq:Int, ing: [Int] ){
    override init(){
        self.tamanoPizza = 0
        self.tipoMasa = 0
        self.tipoQueso = 0
        self.ingredientes = []
    }
    
    func setTamanoPizza(tp: Int){
        self.tamanoPizza = tp
    }
    
    func getTamanoPizza() -> Int{
        return self.tamanoPizza
    }
    
    func setTipoMasa(tm: Int){
        self.tipoMasa = tm
    }
    
    func getTipoMasa() -> Int{
        return self.tipoMasa
    }
    
    func setTipoQueso(tq: Int){
        self.tipoQueso = tq
    }
    
    func getTipoQueso() -> Int{
        return self.tipoQueso
    }
    
    func setIngredientes(ing: [Bool]){
        self.ingredientes = ing
    }
    
    func getIngredientes() -> [Bool]{
        return self.ingredientes
    }
    
    func procesaTamanoPizza(tp: Int) -> String{
        
        var cadena:String = "Tamaño : "
        
        switch tp{
            case 0:
                cadena = cadena + "Chica"
            case 1:
                cadena = cadena + "Mediana"
            default:
                cadena = cadena + "Grande"
        }
        
        return "\(cadena)\n"
    }
    
    func procesaTipoMasa(tm: Int) -> String{
        
        var cadena:String = "Masa : "
        
        switch tm{
            case 0:
                cadena = cadena + "Delgada"
            case 1:
                cadena = cadena + "Crujiente"
            default:
                cadena = cadena + "Gruesa"
        }
        
        return "\(cadena)\n"
    }
    
    func procesaTipoQueso(tq: Int) -> String{
        
        var cadena:String = "Queso : "
        
        switch tq{
            case 0:
                cadena = cadena + "Sin Queso"
            case 1:
                cadena = cadena + "Mozarela"
            case 2:
                cadena = cadena + "Chedar"
            default:
                cadena = cadena + "Parmesano"
        }
        
        return "\(cadena)\n"
    }
    
    func procesaIngredientes(ing: [Bool]) -> String{
        
        var cadena:String = "Ingredientes :\n"
        
        for i in 0..<ing.count{
            if ing[i] {
                switch i{
                    case 0:
                        cadena = cadena + "✓ Jamon\n"
                    case 1:
                        cadena = cadena + "✓ Peperoni\n"
                    case 2:
                        cadena = cadena + "✓ Pavo\n"
                    case 3:
                        cadena = cadena + "✓ Salchicha\n"
                    case 4:
                        cadena = cadena + "✓ Aceituna\n"
                    case 5:
                        cadena = cadena + "✓ Cebolla\n"
                    case 6:
                        cadena = cadena + "✓ Pimienta\n"
                    case 7:
                        cadena = cadena + "✓ Piña\n"
                    default:
                        cadena = cadena + "✓ Anchoa\n"
                    }
            }
        }
        return cadena
    }
}
