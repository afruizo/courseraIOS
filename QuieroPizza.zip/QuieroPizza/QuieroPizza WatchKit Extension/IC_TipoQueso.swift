//
//  IC_TipoQueso.swift
//  QuieroPizza
//
//  Created by Andres Fernando Ruiz Ojeda on 26/11/17.
//  Copyright © 2017 afro. All rights reserved.
//

import WatchKit
import Foundation


class IC_TipoQueso: WKInterfaceController {

    @IBOutlet var pickerQueso: WKInterfacePicker!
    
    var valorTipoQueso: Int = 0
    
    let tipoQueso : [(String, String)] = [
        ("Sin Queso", "Sin Queso"),
        ("Mozarela", "Mozarela"),
        ("Chedar", "Chedar"),
        ("Parmesano", "Parmesano")
    ]
    
    var contexto:ValoresPizza = ValoresPizza()
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        contexto = context as! ValoresPizza
        // Configure interface objects here.
        
        let tipoQuesoItems: [WKPickerItem] = tipoQueso.map{
            let tipoQuesoItem = WKPickerItem()
            tipoQuesoItem.title = $0.0
            tipoQuesoItem.caption = $0.1
            
            return tipoQuesoItem
        }
        
        pickerQueso.setItems(tipoQuesoItems)
        pickerQueso.setSelectedItemIndex(0)
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func obtenerSeleccion(_ value: Int) {
        valorTipoQueso = value
    }
    
    @IBAction func continuarFlujo() {
        contexto.setTipoQueso(tq: valorTipoQueso)
        pushController(withName: "Ingredientes", context: contexto)
    }
}
