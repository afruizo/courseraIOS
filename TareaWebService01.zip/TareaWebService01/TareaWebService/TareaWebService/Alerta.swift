//
//  Alerta.swift
//  TareaWebService
//
//  Created by Andres Fernando Ruiz Ojeda on 11/12/17.
//  Copyright © 2017 afro. All rights reserved.
//

import UIKit

class Alerta: NSObject {

}
