//
//  Valores.swift
//  TareaWebService
//
//  Created by Andres Fernando Ruiz Ojeda on 10/12/17.
//  Copyright © 2017 afro. All rights reserved.
//

import UIKit

class Valores: NSObject {
    
    var url:String = ""
    var isbn:String = ""
    var res:String = ""
    
    override init() {
        self.url = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:"
        self.isbn = ""
        self.res = ""
    }
    
    func setUrl(u:String){
        self.url = u
    }
    
    func getUrl() -> String{
        return self.url
    }
    
    func setIsbn(i:String){
        self.isbn = i
    }
    
    func getIsbn() -> String{
        return self.isbn
    }
    
    func setRes(r:String){
        self.res = r
    }
    
    func getRes() -> String{
        return self.res
    }
    
    func retornaURL() -> String{
        return getUrl() + getIsbn()
    }
    
    func sincrono() -> String{
        let url = URL(string: self.retornaURL())
        let datos:Data? = NSData(contentsOf: url!) as Data?
        
        var texto = ""
        
        if datos == nil{
            texto = "ERROR!"
        } else {
            texto = NSString(data: datos!, encoding:String.Encoding.utf8.rawValue) as! String
            print(texto)
        }
        
        return texto
    }
    
}
