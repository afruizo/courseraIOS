//
//  ViewController.swift
//  TareaWebService
//
//  Created by Andres Fernando Ruiz Ojeda on 10/12/17.
//  Copyright © 2017 afro. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    
    @IBOutlet weak var txtIsbn: UITextField!
    @IBOutlet weak var lblDireccion: UILabel!
    @IBOutlet weak var lblResultado: UILabel!
    
    var url = Valores()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        txtIsbn.delegate = self
        
        //Se muestra en pantalla la url tomada del objeto URL(), ya que se está
        //considerando un hardcode
        self.lblDireccion.text = url.retornaURL()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func didOnExit(_ sender: AnyObject) {
        //Linea que hace que el teclado desaparezca
        txtIsbn.resignFirstResponder()
        
        //Se obtiene el valor de la caja de texto y se guarda en la classe
        url.setIsbn(i: self.txtIsbn.text!)
        
        //Se muestra en la pantalla la nueva url formada
        self.lblDireccion.text = url.retornaURL()
        
        //Se invoca a la funcion que realizara el llamado al web service
        let resultado: String = url.sincrono()
        
        if  resultado == "ERROR!"{
            alerta()
            self.lblResultado.text = ""
        }else{
            if resultado == "{}"{
                self.lblResultado.text = ""
            }else{
                self.lblResultado.text = resultado
            }
        }
        
    }
    
    @IBAction func touchDown(_ sender: AnyObject) {
        txtIsbn.resignFirstResponder()
    }
    
    func alerta(){
        //Crear alerta
        let alert = UIAlertController(title: "Error", message: "Ocurrió un error inesperado al realizar la consulta", preferredStyle: UIAlertControllerStyle.alert)
        
        //Se agrega un boton
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        
        //Se muestra alerta
        self.present(alert, animated: true, completion: nil)
    }

}

